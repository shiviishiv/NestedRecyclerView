package mysoup;

import java.util.List;

public class soupItem {
    private String itemTitle;
    private List<soupSubItem> subItemList;

    public soupItem(String itemTitle, List<soupSubItem> subItemList) {
        this.itemTitle = itemTitle;
        this.subItemList = subItemList;
    }

    public String getItemTitle() {
        return itemTitle;
    }

    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }

    public List<soupSubItem> getSubItemList() {
        return subItemList;
    }

    public void setSubItemList(List<soupSubItem> subItemList) {
        this.subItemList = subItemList;
    }
}
