package com.example.multiplerecycleviewfragmentcardviewviewpager2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.content.ClipData;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

import mysoup.soupItem;
import mysoup.soupItemAdapter;
import mysoup.soupSubItem;

public class MainActivity extends AppCompatActivity {
    private ViewPager2 viewPager2;
    private TabLayout tabLayout;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //secondActivity = SecondActivity.in
        // ActivityFragmentViewPagerBinding
        inits();


        final String[] titles = new String[]{"Soups", "Starters", "Main Course","Beverages","Desc"};
        MyViewPagerAdapter myViewPagerAdapter = new MyViewPagerAdapter(this);
        myViewPagerAdapter.addFragment(new Soup_fragment(),"Soups");
        myViewPagerAdapter.addFragment(new Starter_fragment(),"Starters");
        myViewPagerAdapter.addFragment(new MainCourse(),"Main Course");
        myViewPagerAdapter.addFragment(new Beverage_fragment(),"Beverages");
        myViewPagerAdapter.addFragment(new Desccription_fragment(),"Desc");
        viewPager2.setAdapter(myViewPagerAdapter);
        new TabLayoutMediator(tabLayout, viewPager2,
                new TabLayoutMediator.TabConfigurationStrategy() {
                    @Override
                    public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                        tab.setText(titles[position]);
                    }
                }
        ).attach();

    }

    private void inits() {
      //  toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        viewPager2 = findViewById(R.id.viewPager2);
        tabLayout = findViewById(R.id.tabLayout);

    }

}