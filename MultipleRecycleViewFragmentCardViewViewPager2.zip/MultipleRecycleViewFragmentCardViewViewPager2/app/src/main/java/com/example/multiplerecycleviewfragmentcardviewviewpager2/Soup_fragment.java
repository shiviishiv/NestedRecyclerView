package com.example.multiplerecycleviewfragmentcardviewviewpager2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import mysoup.soupItem;
import mysoup.soupItemAdapter;
import mysoup.soupSubItem;

public class Soup_fragment extends Fragment {

 @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_soup_fragment, container, false);
     RecyclerView rvItem = view.findViewById(R.id.rv_item);
     RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
     soupItemAdapter itemAdapter = new soupItemAdapter(buildItemList());
     rvItem.setAdapter(itemAdapter);
     rvItem.setLayoutManager(layoutManager);
     return view;
    }
    private List<soupItem> buildItemList() {
        List<soupItem> itemList = new ArrayList<>();
        for (int i=0; i<10; i++) {
            soupItem item = new soupItem("Item "+i, buildSubItemList());
            itemList.add(item);
        }
        return itemList;
    }

    private List<soupSubItem> buildSubItemList() {
        List<soupSubItem> subItemList = new ArrayList<>();
        for (int i=0; i<3; i++) {
            soupSubItem subItem = new soupSubItem("Sub Item "+i, "Description "+i);
            subItemList.add(subItem);
        }
        return subItemList;
    }
}